package com.xebia.shortnotes.domain;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Note.class)
public class NoteDataOnDemand {
}
