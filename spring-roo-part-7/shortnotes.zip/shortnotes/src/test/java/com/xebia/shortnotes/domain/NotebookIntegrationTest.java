package com.xebia.shortnotes.domain;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Notebook.class, transactional = false)
public class NotebookIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
