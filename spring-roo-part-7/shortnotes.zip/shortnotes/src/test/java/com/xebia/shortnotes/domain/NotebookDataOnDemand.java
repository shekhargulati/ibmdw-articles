package com.xebia.shortnotes.domain;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Notebook.class)
public class NotebookDataOnDemand {
}
