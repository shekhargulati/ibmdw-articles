package com.xebia.shortnotes.service;


public class NotebookServiceImpl implements NotebookService {
}
