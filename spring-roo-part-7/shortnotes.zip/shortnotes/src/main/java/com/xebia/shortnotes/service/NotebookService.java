package com.xebia.shortnotes.service;

import org.springframework.roo.addon.layers.service.RooService;

@RooService(domainTypes = { com.xebia.shortnotes.domain.Notebook.class })
public interface NotebookService {
}
